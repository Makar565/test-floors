<?php

$host = 'localhost'; 
$database = 'h96568b5_floors'; 
$user = 'h96568b5_floors';
$password = '1C9*nsSw';
?>